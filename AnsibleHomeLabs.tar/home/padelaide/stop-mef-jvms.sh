#!/bin/bash
task="stop-mef-jvms"
# start
#
date
pwd
id
hostname
#
echo ""
echo "*** Running [ su - wasadmin -c '/opt/IBM/WebSphere855/AppServer/scripts/mef_app_ctl.sh stop no' ] ***"

thisHost=`hostname`
if [[ "$thisHost" == *"f2app"* ]] | [[ "$thisHost" == *"f4app"* ]] ; then
  echo "BYPASSED: [$thisHost] does not qualify to run [$task], exiting script..."
  exit
fi

# su - wasadmin -c "/opt/IBM/WebSphere855/AppServer/scripts/mef_app_ctl.sh stop no"
/opt/IBM/WebSphere855/AppServer/scripts/mef_app_ctl.sh stop no

echo "Return Code for [ su - wasadmin -c '/opt/IBM/WebSphere855/AppServer/scripts/mef_app_ctl.sh stop no' ]:[$?]"
echo ""
